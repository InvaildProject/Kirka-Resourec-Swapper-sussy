
# Resource swapper extension for kirka.io

Just download the source code and then manually install it.

By default vita, shark and bayonet skins are swapped with love, kiss and butterflies as an example you can swap them to whatever skins you like.


# Steps to install

1. Download the source code zip
2. Extract it on your desktop
3. A tutorial to install the extension https://www.youtube.com/watch?v=dhaGRJvJAII
4. Everytime you change some skins you have to restart your browser for it to be in effect.
